#include "assignment.h"

// ex. 4 function: disptach work to other functions for exercise 4
void ex4() {

}

#ifdef JOJ
int main(){
    ex4();
    return 0;
}
#endif
